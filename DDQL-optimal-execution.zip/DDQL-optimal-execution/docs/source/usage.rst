
Installation
============


The DDQL-optimal-execution source code is available on GitHub. 

You can either install the package using pip :

.. code-block:: bash

    $ pip install ddql_optimal_execution 

or clone the repository with the following command.

.. code-block:: bash

    $ git clone https://github.com/g0bel1n/DDQL-optimal-execution.git
    $ cd DDQL-optimal-execution
    $ pip install -r requirements.txt

